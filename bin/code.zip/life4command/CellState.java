package life4command;

public interface CellState {
	public CellState die();
	public CellState live();
	public boolean isAlive();
	
	
		
	
}
