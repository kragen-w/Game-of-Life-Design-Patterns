package life5observer;

public interface CellState {
	public CellState die();
	public CellState live();
	public boolean isAlive();
	
	
		
	
}
